from Crypto.Util.number import getPrime
from FLAG import flag


flag = int(flag.hex(), 16)
num = 6
e = 0x10001
p = [getPrime(1024) for _ in range(num)]
f = open('cipherlist.txt', 'w')
for i in range(num):
    for j in range(i + 1, num):
        for k in range(j + 1, num):
            n = p[i] * p[j] * p[k]
            f.write(hex(pow(flag, e, n)) + '\n')
0 1 2
0 1 3
0 1 4
0 1 5
0 2 3
0 2 4
0 2 5
0 3 4
0 3 5
0 4 5
1 2 3
1 2 4
1 2 5
1 3 4
1 3 5
1 4 5
2 3 4
2 3 5
2 4 5
3 4 5

k1 * p1 + c1 = k2 * p2 + c2
m = c1 (mod p1)  m = k1*p1 + c1
m = c2 (mod p2)  m = k2*p2 + c2
m = c3 (mod p3)  m = k3*
