0x53c079c6d47fd7399c1ceee171db7141c35a6f44@ropsten

Solved: 3
Point:  909