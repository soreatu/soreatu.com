Solved: 4
Point:  869