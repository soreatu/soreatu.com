nc 121.41.38.38 9999

Solved: 28
Point:  425