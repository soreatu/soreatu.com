nc 121.40.246.48 9999

Solved: 28
Point:  425