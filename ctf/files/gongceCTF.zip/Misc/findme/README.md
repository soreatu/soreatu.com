Solved: 33
Point:  384