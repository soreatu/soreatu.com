# coding=utf-8
import socket
import thread
import os

flag="flag{xxxxxxxxxxxxxxxxx}"

def remote_sub(conn, address):
    print address,
    (ip,port)=address
    conn.settimeout(20)
    secret=int(os.urandom(16).encode("hex"),16)
    #conn.send(hex(secret))
    ground=0
    sky=pow(2,128)
    for i in range(200):
        conn.send("g\n")
        newground=int(conn.recv(1024).strip(),16)
        conn.send("s\n")
        newsky=int(conn.recv(1024).strip(),16)
        if newground<ground or newsky>sky or newground>newsky:
            conn.close()
            return
        ground=newground
        sky=newsky
        if secret <ground or secret >sky:
            conn.close()
            return

        conn.send("g1\n")
        g1 = int(conn.recv(1024).strip(), 16)
        conn.send("g2\n")
        g2 = int(conn.recv(1024).strip(), 16)

        if abs(g2-g1) > abs(sky-ground)/3+1:
            conn.close()
            return

        if g1==secret and g2==secret:
            conn.send(flag+"\n")
        else:
            if pow(abs(secret-g1)-abs(secret-g2),2)<pow(abs(g2-g1),2):
                conn.send("1\n")
            else:
                conn.send("2\n")
    conn.close()
    return
def remote():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("0.0.0.0", 9999))
    sock.listen(0)
    while True:
        thread.start_new_thread(remote_sub, sock.accept())
if __name__ == '__main__':
    remote()
