Solved: 76
Point:  210